import BetaSettings from './BetaSettings';

export default function MemberSettings() {
  return <BetaSettings />;
}
