-- Add revolut_link column to products table
ALTER TABLE public.products 
ADD COLUMN revolut_link text;